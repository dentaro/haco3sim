function setup()
  color(0,0,0)
  fillrect(0,0,128,128);
  color(255,255,255)
  text("Hello World", 32, 32)
end

function loop()
end
