# haco3 Simulator

o-bako シミュレータのレイアウトをhaco3仕様に直しただけのものです。 
エディター作成のためにaceを利用しています。 Luaの実行のために https://fengari.io/ を利用しています。