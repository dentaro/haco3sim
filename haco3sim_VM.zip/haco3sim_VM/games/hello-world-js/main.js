setup = function(){
}
c = 0
loop = function(){
    color(0,0,0)
    fillrect(0,0,128,128)
    color(255,255,255)
    text("Hello World", 10, c%128)
    c ++
}
// setup = function(){
//   color(0,0,0)
//   fillrect(0,0,128,128)
// }
// x = 16;
// y = 16;
// step =1;
// loop = function(){
//     color(0,0,0)
//     fillrect(0,0,128,128)
//     if(btn(0)>0){x -= step;}
//     if(btn(1)>0){x += step;}
//     if(btn(2)>0){y -= step;}
//     if(btn(3)>0){y += step;}
//     spr(x, y, 8, 8, 8*2, 8*0)
// }
