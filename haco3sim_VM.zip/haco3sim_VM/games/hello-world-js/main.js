title = "BALL TOUR";

y = 64;
rad = 0;
bx = 0;
step =1;
oy=[0,0,0,0];
ox=[0,0,0,0] ;
over_c = 0;

modetitle = 0
modegame = 1
modeover = 2
mode = modetitle

//オブジェクトを作る
class Obj = {
  constructor(x, y) {
    this.x = x;
    this.y = y;
  }
  addv(vx,vy) {
    this.x += vx;
    this.x += vy;
  }
}

class Hito extends Obj = {
}
class Teki extends Obj = {
}
class Kane extends Obj = {
}

setup = function(){
  const hito = new Hito(0,0,10,10);//私
  const kane = new Kane(0,0,10,10);//金
  const teki = new Teki(0,0,10,10);//敵
}

loop = function(){
    if (mode == modetitle)title()
    else if(mode == modegame)game()
    else if(mode == modeover)over()
}

title = function(){
    color(255,255,0)
    fillrect(0,0,128,128)
    color(0,0,0)
    text("[Hold]Move forward",0, 0)
    if(btn(1)==true){
        mode = modegame;
    }
}

over = function(){
    color(255,0,255)
    fillrect(0,0,128,128)
    color(0,0,0)
    text("game over",0, 0)

    if(btn(1)==true){
        mode = modetitle;
        ox[0] =0
    }
}

game = function(){
    color(0,0,0)
    fillrect(0,0,128,128)
    if(c<100){
        color(255,0,0)
        text(description,0,0)

    }else{
        y=Math.sin(rad)*40;
        spr(112, 64+y, 8, 8, 8*2, 8*8)

        rad+=6.28/180;//2度ずつ進みます
        rad%=6.28;

    }


    if(btn(1)>0){
        ox[0] += step;
        ox[1] += step;
    }


    if((ox[0])>128){
        oy[0] = Math.random()*112;
        oy[1] = Math.random()*112;
        ox[0] = (ox[0])%128;
    }



    spr(ox[0]%128, oy[0], 8, 8, 8*0, 8*3)//メダル
    spr(ox[0]%128, oy[1], 8, 8, 8*2, 8*3)//石


    // if((ox[1]-32)>128){
    //     oy[2] = Math.random()*112;
    //     oy[3] = Math.random()*112;
    //     ox[1] = (ox[1])%128;//この+の値でフェイズを起こす
    // }
    //
    // spr(ox[1]-32%128, oy[2], 8, 8, 8*0, 8*3)//メダル
    // spr(ox[1]-32%128, oy[3], 8, 8, 8*2, 8*3)//石

    //当たり判定
    // for(i = 0; i < e.length; i++){
    //     c[0].x = e[i].x;
    //
    // }


}
