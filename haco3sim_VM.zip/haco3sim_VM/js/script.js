  const PIXEL_SIZE = 6;        // 1ドットの大きさ
  const canvasWidth = PIXEL_SIZE * 128;   // キャンバス横幅1536
  const canvasHeight = PIXEL_SIZE * 128;  // キャンバス縦幅1536


var file = document.getElementById('file');
// var canvas0 = document.getElementById('canvas0');
var canvas = document.getElementById('canvas');
var uploadImgSrc;


// Canvasの準備
canvas.width = canvasWidth;
canvas.height = canvasHeight;

// レイヤーCanvasの準備
// canvas0.width = canvasWidth;
// canvas0.height = canvasHeight;

// var ctx0 = canvas0.getContext('2d');
var ctx = canvas.getContext('2d');
let _drawing = false;


 /**
//    * MouseEventまたはTouchからCanvas内での座標を算出して返却
//    * @param {MouseEvent|Touch}
//    * @return {Object} x: x座標, y: y座標
//    */

  const getCoordsByEvent = e => {
    const bounds = e.target.getBoundingClientRect();
    return {
      x: e.clientX - bounds.left,
      y: e.clientY - bounds.top
    };
  };

  /**
   * RGBを指定してコンテキストに描画色を設定する
   * @param {Number} R
   * @param {Number} G
   * @param {Number} B
   */
  const setBrushColor = (r, g, b) => {
    ctx.fillStyle = 'rgba('+ r +','+ g +','+ b +', 1)';
  };

  // /**
  //  * Canvas内の座標を指定して、描画モードONならドットを描画する
  //  * @param {Number} x座標
  //  * @param {Number} y座標
  //  */
  const draw = (x, y) => {
    if (_drawing) {
      // ドットの左上の座標を算出
      const upperLeftX = Math.floor(x / canvas.width * canvasWidth / PIXEL_SIZE) * PIXEL_SIZE;
      const upperLeftY = Math.floor(y / canvas.height * canvasHeight / PIXEL_SIZE) * PIXEL_SIZE;

      // ドットの大きさの矩形を描画
      ctx.fillRect(upperLeftX, upperLeftY, PIXEL_SIZE, PIXEL_SIZE);
    }
  };


  // // Canvasの幅と高さを設定
  // canvas.width  = canvasWidth;
  // canvas.height = canvasHeight;

  // 不透明の黒で塗りつぶす
  setBrushColor(0, 0, 0);
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // 初期描画色を白に
  setBrushColor(255, 255, 255);

  // 左クリックで描画モードON ＋ 1発目の描画
  canvas.addEventListener('mousedown', e => {
    if (e.button <= 1) {
      _drawing = true;

      // Canvas内での左上からの座標を算出して描画
      const coords = getCoordsByEvent(e);
      draw(coords.x, coords.y);
    }
  });
  // タップ開始で同上
  canvas.addEventListener('touchstart', e => {
    // ※マルチタッチ考慮せず
    _drawing = true;
    const coords = getCoordsByEvent(e.changedTouches[0]);
    draw(coords.x, coords.y);
  });

  // 左クリックで描画モードOFF
  canvas.addEventListener('mouseup', e => {
    if (e.button <= 1) {
      _drawing = false;
    }
  });
  // タップ終了で同上 (※マルチタッチ考慮せず)
  canvas.addEventListener('touchend', () => {
    _drawing = false;
  });

  // カーソル移動で描画
  canvas.addEventListener('mousemove', e => {
    const coords = getCoordsByEvent(e);
    draw(coords.x, coords.y);
  });
  // 指移動で同上 (※マルチタッチ考慮せず)
  canvas.addEventListener('touchmove', e => {
    e.preventDefault(); // スクロール防止
    const coords = getCoordsByEvent(e.changedTouches[0]); // 1本目の指だけ使う
    draw(coords.x, coords.y);
  });



  // 描画色変更
  document.getElementById('brush-color').addEventListener('change', e => {
    const code = e.target.value;
    const r = parseInt(code.substr(1, 2), 16);
    const g = parseInt(code.substr(3, 2), 16);
    const b = parseInt(code.substr(5, 2), 16);
    setBrushColor(r, g, b);
  });

function onMouseOver() {
    // gridDraw();
}
function onMouseOut() {
    // ctx.clearRect(0, 0, canvas.width, canvas.height);
}
function gridDraw() {

  // for (let i = 0; i < 16; i++){
  //   // パスをリセット
  //   ctx.beginPath () ;

  //   // 線を引くスタート地点に移動
  //   ctx.moveTo( 48*i, 0 ) ;
  //   // スタート地点から(200,200)まで線を引く
  //   ctx.lineTo( 48*i, 768 );

  //   // 線を引くスタート地点に移動
  //   ctx.moveTo( 0 , 48*i);
  //   // スタート地点から(200,200)まで線を引く
  //   ctx.lineTo( 768, 48*i );

  //   // 線の色
  //   ctx.strokeStyle = "#fff" ;
  //   // 線の太さ
  //   ctx.lineWidth = 1 ;

  //   // 線を描画する
  //   ctx.stroke() ;
  // }
}

canvas.addEventListener('mouseover', onMouseOver, false);
canvas.addEventListener('mouseout', onMouseOut, false);

function loadLocalImage(e) {
  // ファイル情報を取得
  var fileData = e.target.files[0];

  // 画像ファイル以外は処理を止める
  if(!fileData.type.match('image.*')) {
    alert('画像を選択してください');
    return;
  }

  // FileReaderオブジェクトを使ってファイル読み込み
  var reader = new FileReader();
  // ファイル読み込みに成功したときの処理
  reader.onload = function() {
    // Canvas上に表示する
    uploadImgSrc = reader.result;

    canvasDraw();

  }
  // ファイル読み込みを実行
  reader.readAsDataURL(fileData);
}

// ファイルが指定された時にloadLocalImage()を実行
file.addEventListener('change', loadLocalImage, false);

// Canvas上に画像を表示する
function canvasDraw() {
  // canvas内の要素をクリアする
  ctx.clearRect(0, 0, canvasWidth, canvasHeight);

  // Canvas上に画像を表示
  var img = new Image();
  img.src = uploadImgSrc;
  img.onload = function() {
    ctx.mozImageSmoothingEnabled = false;
    ctx.webkitImageSmoothingEnabled = false;
    ctx.msImageSmoothingEnabled = false;
    ctx.imageSmoothingEnabled = false;
    // ctx.globalAlpha = 0.5;
    ctx.drawImage(img, 0, 0, canvasWidth, this.height * (canvasWidth / this.width));
  }
}

// canvasを画像で保存
  download.addEventListener("click", function(e){
    ctx.drawImage(this ,0,0, this.width , this.height , 0,0,128,128);//縮小して

    canvas = document.getElementById('canvas');
    var base64 = canvas.toDataURL("image/png");
    document.getElementById("download").href = base64;

  });


resizeImage = function(base64, callback) {
   const MIN_SIZE = 800;
   var canvas = document.createElement('canvas');
   var ctx = canvas.getContext('2d');

   var image = new Image();
   image.crossOrigin = "Anonymous";
   image.onload = function(event){
       var dstWidth, dstHeight;
       if (this.width > this.height) {
           dstWidth = MIN_SIZE;
           dstHeight = this.height * MIN_SIZE / this.width;
       } else {
           dstHeight = MIN_SIZE;
           dstWidth = this.width * MIN_SIZE / this.height;
       }
       canvas.width = dstWidth;
       canvas.height = dstHeight;
       ctx.drawImage(this, 0, 0, this.width, this.height, 0, 0, dstWidth, dstHeight);
       callback(canvas.toDataURL());
   };
   image.src = base64;
};


// //------------------------------------------------------------
var file = document.getElementById('file');
var result = document.getElementById('result');

// File APIに対応しているか確認
if(window.File && window.FileReader && window.FileList && window.Blob) {
    // function loadLocalImage(e) {
    //     // ファイル情報を取得
    //     var fileData = e.target.files[0];
    //     console.log(fileData); // 取得した内容の確認用

    //     // 画像ファイル以外は処理を止める
    //     if(!fileData.type.match('image.*')) {
    //         alert('画像を選択してください');
    //         return;
    //     }

    //     // FileReaderオブジェクトを使ってファイル読み込み
    //     var reader = new FileReader();

    //     // ファイル読み込みに成功したときの処理
    //     reader.onload = function() {
    //       // Canvas上に表示する
    //       uploadImgSrc = reader.result;
    //       canvasDraw();
    //     }

    //     // // ファイル読み込みに成功したらブラウザに表示する
    //     // reader.onload = function() {
    //     //     var img = document.createElement('img');
    //     //     img.src = reader.result;
    //     //     result.appendChild(img);
    //     // }

    //     // ファイル読み込みを実行
    //     reader.readAsDataURL(fileData);
    // }
    // // ファイルが指定された時にloadLocalImage()を実行
    // file.addEventListener('change', loadLocalImage, false);

    // // Canvas上に画像を表示する
    // function canvasDraw() {
    //   // canvas内の要素をクリアする
    //   ctx.clearRect(0, 0, canvasWidth, CANVAS_HIGHT);
    //   // Canvas上に画像を表示
    //   var img = new Image();
    //   img.src = uploadImgSrc;
    //   img.onload = function() {
    //     ctx.drawImage(img, 0, 0, canvasWidth, this.height * (canvasWidth / this.width));
    //   }
    // }



} else {
    file.style.display = 'none';
    result.innerHTML = 'File APIに対応したブラウザでご確認ください';
}
